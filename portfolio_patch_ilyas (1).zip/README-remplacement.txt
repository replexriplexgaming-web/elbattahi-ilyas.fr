Fichiers modifiés pour améliorer le portfolio.

À remplacer dans ton site existant :
- portfolio.html
- index.html
- assets/css/custom.css

Garde tous tes autres dossiers actuels : images, documents, assets/js, assets/css/main.css, etc.
